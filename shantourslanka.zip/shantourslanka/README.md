skdslider
=========

Jquery full width image slider

It is very light weight full width jquery image slider.  

For demo visit: http://dandywebsolution.com/skdslider/
